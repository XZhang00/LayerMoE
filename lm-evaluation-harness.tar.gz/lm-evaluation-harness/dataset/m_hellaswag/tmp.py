from datasets import load_dataset
import json

path = "lm-evaluation-harness/dataset/m_hellaswag/zh_validation.json"

data  = json.load(open(path))
print(len(data))

# keys = ['ctx_a', 'ctx_b', 'ctx', 'endings', 'id', 'ind', 'activity_label', 'source_id', 'split', 'split_type', 'label']
# keys_type_dict = {}

# for item in data[:1]:
#     for i in keys:
#         print(type(item[i]))
#         keys_type_dict[i] = type(item[i])
#     print(keys_type_dict)


# for item in data[1:]:
#     for i in keys:
#         assert keys_type_dict[i] == type(item[i])

save_path = "lm-evaluation-harness/dataset/m_hellaswag/hellaswag_zh.json"
with open(save_path, "w", encoding="utf-8") as fw:
    for item in data:
        fw.write(json.dumps(item) + '\n')
    fw.close()
# json.dump({"data": data}, open(save_path, 'w', encoding="utf-8"), indent=4, ensure_ascii=False)



dataset = load_dataset("json", data_files=save_path)
# , field="data"

print(len(dataset))
