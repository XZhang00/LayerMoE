import yaml
import os

paths = os.listdir("lm-evaluation-harness/lm_eval/tasks/mmlu_tr/default")
print(len(paths))
paths.sort()

keys = ['dataset_name', 'description', 'tag', 'include', 'task', 'task_alias']

fr = open("lm-evaluation-harness/lm_eval/tasks/mmlu_tr/default/trans2tr.txt", 'r', encoding="utf-8")
trans2el = fr.readlines()
print(len(trans2el))
cnt = 0

for i_path in paths:
    # print(i_path)
    if i_path[0] == "_" or ".yaml" not in i_path:  continue
    path = "lm-evaluation-harness/lm_eval/tasks/mmlu_tr/default/" + i_path

    with open(path, 'r') as file:
        data = yaml.safe_load(file)

    assert set(list(data.keys())) == set(keys)


    for key in keys:
        if key == "description":
            data["description"] = trans2el[cnt] + "\n"
            for i in ['tag', 'task', 'task_alias']:
                data[i] = data[i] + "_tr"

    cnt += 1
    with open(path, "w", encoding="utf-8") as yaml_file:
            yaml.dump(
                data,
                yaml_file,
                allow_unicode=True,
                default_style='"',
            )

assert cnt == len(trans2el)