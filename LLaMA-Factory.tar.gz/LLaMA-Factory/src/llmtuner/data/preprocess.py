from functools import partial
import math
import torch
from itertools import chain
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Literal, Tuple

from ..extras.constants import IGNORE_INDEX
from ..extras.logging import get_logger
from .utils import Role, LANGS, LANG_TO_RECOVER



if TYPE_CHECKING:
    from transformers import Seq2SeqTrainingArguments
    from transformers.tokenization_utils import PreTrainedTokenizer

    from ..hparams import DataArguments
    from .template import Template


logger = get_logger(__name__)


def preprocess_pretrain_dataset(
    examples: Dict[str, List[Any]], tokenizer: "PreTrainedTokenizer", data_args: "DataArguments"
) -> Dict[str, List[List[int]]]:
    # build grouped texts with format `X1 X2 X3 ...`
    text_examples = [examples["prompt"][i][0]["content"] for i in range(len(examples["prompt"]))]
    tokenized_examples = tokenizer(text_examples, add_special_tokens=False)

    if "language" in examples:
        langs = examples["language"]
        assert len(langs) == len(tokenized_examples["input_ids"])

    for i in range(len(tokenized_examples["input_ids"])):
        tokenized_examples["input_ids"][i] += [tokenizer.eos_token_id]
        tokenized_examples["attention_mask"][i] += [1]

    if "language" in examples:
        langs_mask = [[LANG_TO_RECOVER[k]] * len(v) for k, v in zip(langs, tokenized_examples["input_ids"])]
        tokenized_examples['langs'] = langs_mask

    if "group_tag" in examples:
        group_tags_tmp = examples["group_tag"]
        assert len(group_tags_tmp) == len(tokenized_examples["input_ids"])
        if data_args.different_old_experts:
            GROUP_TO_EXPERTS = {"g0": [0], "g1": [1], "g2": [2]}
        elif data_args.per_language_experts_num == 1:  # 默认先设置 3-experts + 3-experts 的训练
            GROUP_TO_EXPERTS = {"g0": [0, -100, -100, -100], "g1": [0, 1, 2, 3], "g2": [-100, -100, -100, -100]}
        else:
            print("error!!! no support for more experts.")
            hhhh 
        group_tags = [[GROUP_TO_EXPERTS[k]] * len(v) for k, v in zip(group_tags_tmp, tokenized_examples["input_ids"])]
        # print(group_tags)
        tokenized_examples["group_tags"] = group_tags

    # if "lang_tag" in examples:
    #     lang_tags_tmp = examples["lang_tag"]
    #     # print("@@@@-preprocess: lang_tags_tmp", len(lang_tags_tmp), lang_tags_tmp)
    #     assert len(lang_tags_tmp) == len(tokenized_examples["input_ids"])
    #     if data_args.per_language_experts_num == 1:
    #         if data_args.specific_ori_agnostic:
    #             LANG_TO_EXPERTS = {"el": [1, 0], "hu": [2, 0], "tr": [3, 0]} 
    #         elif data_args.specific_agnostic:
    #             LANG_TO_EXPERTS = {"el": [1, 4], "hu": [2, 4], "tr": [3, 4]} 
    #         else:
    #             LANG_TO_EXPERTS = {"el": 1, "hu": 2, "tr": 3} 
    #     elif data_args.per_language_experts_num == 2:
    #         if data_args.specific_ori_agnostic:
    #             LANG_TO_EXPERTS = {"el": [1, 2, 0], "hu": [3, 4, 0], "tr": [5, 6, 0]} 
    #         elif data_args.specific_agnostic:
    #             LANG_TO_EXPERTS = {"el": [1, 2, 7], "hu": [3, 4, 7], "tr": [5, 6, 7]} 
    #         else:
    #             LANG_TO_EXPERTS = {"el": [1, 2], "hu": [3, 4], "tr": [5, 6]}
    #     else:
    #         print("error!!! no support for more experts.")
    #         hhhh   
    #     lang_tags = [[LANG_TO_EXPERTS[k]] * len(v) for k, v in zip(lang_tags_tmp, tokenized_examples["input_ids"])]
    #     tokenized_examples['lang_tags'] = lang_tags

    concatenated_examples = {k: list(chain(*tokenized_examples[k])) for k in tokenized_examples.keys()}
    total_length = len(concatenated_examples[list(concatenated_examples.keys())[0]])
    block_size = data_args.cutoff_len
    # we drop the small remainder, and if the total_length < block_size, we exclude this batch
    total_length = (total_length // block_size) * block_size
    # split by chunks of cutoff_len
    result = {
        k: [t[i : i + block_size] for i in range(0, total_length, block_size)]
        for k, t in concatenated_examples.items()
    }
    return result


def preprocess_supervised_dataset(
    examples: Dict[str, List[Any]],
    tokenizer: "PreTrainedTokenizer",
    template: "Template",
    data_args: "DataArguments",
) -> Dict[str, List[List[int]]]:
    # build inputs with format `<bos> X Y <eos>` and labels with format `<ignore> ... <ignore> Y <eos>`
    # for multiturn examples, we only mask the prompt part in each prompt-response pair.
    model_inputs = {"input_ids": [], "attention_mask": [], "labels": []}

    for i in range(len(examples["prompt"])):
        if len(examples["prompt"][i]) % 2 != 1 or len(examples["response"][i]) != 1:
            continue

        messages = examples["prompt"][i] + examples["response"][i]
        input_ids, labels = [], []
        for turn_idx, (source_ids, target_ids) in enumerate(
            template.encode_multiturn(
                tokenizer, messages, examples["system"][i], examples["tools"][i], data_args.cutoff_len
            )
        ):
            if data_args.train_on_prompt:
                source_mask = source_ids
            elif turn_idx != 0 and template.efficient_eos:
                source_mask = [tokenizer.eos_token_id] + [IGNORE_INDEX] * (len(source_ids) - 1)
            else:
                source_mask = [IGNORE_INDEX] * len(source_ids)

            input_ids += source_ids + target_ids
            labels += source_mask + target_ids

        if template.efficient_eos:
            input_ids += [tokenizer.eos_token_id]
            labels += [tokenizer.eos_token_id]

        model_inputs["input_ids"].append(input_ids)
        model_inputs["attention_mask"].append([1] * len(input_ids))
        model_inputs["labels"].append(labels)

    return model_inputs

def truncation(ids_a: List[List[int]], ids_b: List[List[int]], maxlen: int):
    res_a, res_b = [], []
    for a, b in zip(ids_a, ids_b):
        max_a_len = math.ceil(maxlen * len(a) / (len(a) + len(b)))
        max_b_len = math.ceil(maxlen * len(b) / (len(a) + len(b)))
        res_a.append(a[:max_a_len])
        res_b.append(b[:max_b_len])
    return res_a, res_b

def preprocess_mt_supervised_dataset(
    examples: Dict[str, List[Any]],
    tokenizer: "PreTrainedTokenizer",
    template: "Template",
    data_args: "DataArguments",
) -> Dict[str, List[List[int]]]:
    # build inputs with format `<bos> X Y <eos>` and labels with format `<ignore> ... <ignore> Y <eos>`
    # for multiturn examples, we only mask the prompt part in each prompt-response pair.
    src, tgt = examples[data_args.src_lang], examples[data_args.tgt_lang]
    src = [k.strip() for k in src]
    tgt = [k.strip() for k in tgt]
    prompt = "Translate from {} to {}: ".format(LANGS[data_args.src_lang], LANGS[data_args.tgt_lang])
    prompt += "{} => "
    src = [prompt.format(k) for k in src]
    src_inputs = tokenizer(src)['input_ids']
    tgt_inputs = tokenizer(tgt, add_special_tokens=False)['input_ids']

    src_inputs, tgt_inputs = truncation(src_inputs, tgt_inputs, data_args.cutoff_len - 1)

    langs = [[0] * len(a) + [1] * len(b) + [0] for a, b in zip(src_inputs, tgt_inputs)]
    ids = [a + b + [tokenizer.eos_token_id] for a, b in zip(src_inputs, tgt_inputs)]
    labels = [[IGNORE_INDEX] * len(a) + b + [tokenizer.eos_token_id] for a, b in zip(src_inputs, tgt_inputs)]

    return {"input_ids": ids, "labels": labels, "langs": langs}

def preprocess_packed_supervised_dataset(
    examples: Dict[str, List[Any]],
    tokenizer: "PreTrainedTokenizer",
    template: "Template",
    data_args: "DataArguments",
) -> Dict[str, List[List[int]]]:
    # build inputs with format `<bos> X1 Y1 <eos> <bos> X2 Y2 <eos>`
    # and labels with format `<ignore> ... <ignore> Y1 <eos> <ignore> ... <ignore> Y2 <eos>`
    model_inputs = {"input_ids": [], "attention_mask": [], "labels": []}
    input_ids, labels = [], []
    for i in range(len(examples["prompt"])):
        if len(examples["prompt"][i]) % 2 != 1 or len(examples["response"][i]) != 1:
            continue

        messages = examples["prompt"][i] + examples["response"][i]
        for turn_idx, (source_ids, target_ids) in enumerate(
            template.encode_multiturn(tokenizer, messages, examples["system"][i], examples["tools"][i])
        ):
            if data_args.train_on_prompt:
                source_mask = source_ids
            elif turn_idx != 0 and template.efficient_eos:
                source_mask = [tokenizer.eos_token_id] + [IGNORE_INDEX] * (len(source_ids) - 1)
            else:
                source_mask = [IGNORE_INDEX] * len(source_ids)

            input_ids += source_ids + target_ids
            labels += source_mask + target_ids

    if template.efficient_eos:
        input_ids += [tokenizer.eos_token_id]
        labels += [tokenizer.eos_token_id]

    total_length = len(input_ids)
    block_size = data_args.cutoff_len
    # we drop the small remainder, and if the total_length < block_size, we exclude this batch
    total_length = (total_length // block_size) * block_size
    # split by chunks of cutoff_len
    for i in range(0, total_length, block_size):
        model_inputs["input_ids"].append(input_ids[i : i + block_size])
        model_inputs["attention_mask"].append([1] * block_size)
        model_inputs["labels"].append(labels[i : i + block_size])

    return model_inputs


def preprocess_unsupervised_dataset(
    examples: Dict[str, List[Any]],
    tokenizer: "PreTrainedTokenizer",
    template: "Template",
    data_args: "DataArguments",
) -> Dict[str, List[List[int]]]:
    # build inputs with format `<bos> X` and labels with format `Y <eos>`
    model_inputs = {"input_ids": [], "attention_mask": [], "labels": []}

    for i in range(len(examples["prompt"])):
        if len(examples["prompt"][i]) % 2 != 1:
            continue

        if len(examples["response"][i]) == 1:
            messages = examples["prompt"][i] + examples["response"][i]
        else:
            messages = examples["prompt"][i] + [{"role": Role.ASSISTANT, "content": ""}]

        input_ids, labels = template.encode_oneturn(
            tokenizer, messages, examples["system"][i], examples["tools"][i], data_args.cutoff_len
        )

        if template.efficient_eos:
            labels += [tokenizer.eos_token_id]

        model_inputs["input_ids"].append(input_ids)
        model_inputs["attention_mask"].append([1] * len(input_ids))
        model_inputs["labels"].append(labels)

    return model_inputs


def preprocess_pairwise_dataset(
    examples: Dict[str, List[Any]],
    tokenizer: "PreTrainedTokenizer",
    template: "Template",
    data_args: "DataArguments",
) -> Dict[str, List[List[int]]]:
    # build input pairs with format `<bos> X`, `Y1 <eos>` and `Y2 <eos>`
    model_inputs = {"prompt_ids": [], "chosen_ids": [], "rejected_ids": []}
    for i in range(len(examples["prompt"])):
        if len(examples["prompt"][i]) % 2 != 1 or len(examples["response"][i]) < 2:
            continue

        chosen_messages = examples["prompt"][i] + [examples["response"][i][0]]
        rejected_messages = examples["prompt"][i] + [examples["response"][i][1]]

        prompt_ids, chosen_ids = template.encode_oneturn(
            tokenizer, chosen_messages, examples["system"][i], examples["tools"][i], data_args.cutoff_len
        )
        _, rejected_ids = template.encode_oneturn(
            tokenizer, rejected_messages, examples["system"][i], examples["tools"][i], data_args.cutoff_len
        )

        if template.efficient_eos:
            chosen_ids += [tokenizer.eos_token_id]
            rejected_ids += [tokenizer.eos_token_id]

        model_inputs["prompt_ids"].append(prompt_ids)
        model_inputs["chosen_ids"].append(chosen_ids)
        model_inputs["rejected_ids"].append(rejected_ids)

    return model_inputs


def print_supervised_dataset_example(example: Dict[str, List[int]], tokenizer: "PreTrainedTokenizer") -> None:
    print("input_ids:\n{}".format(example["input_ids"]))
    print("inputs:\n{}".format(tokenizer.decode(example["input_ids"], skip_special_tokens=False)))
    print("label_ids:\n{}".format(example["labels"]))
    print(
        "labels:\n{}".format(
            tokenizer.decode(list(filter(lambda x: x != IGNORE_INDEX, example["labels"])), skip_special_tokens=False)
        )
    )


def print_pairwise_dataset_example(example: Dict[str, List[int]], tokenizer: "PreTrainedTokenizer") -> None:
    print("prompt_ids:\n{}".format(example["prompt_ids"]))
    print("prompt:\n{}".format(tokenizer.decode(example["prompt_ids"], skip_special_tokens=False)))
    print("chosen_ids:\n{}".format(example["chosen_ids"]))
    print("chosen:\n{}".format(tokenizer.decode(example["chosen_ids"], skip_special_tokens=False)))
    print("rejected_ids:\n{}".format(example["rejected_ids"]))
    print("rejected:\n{}".format(tokenizer.decode(example["rejected_ids"], skip_special_tokens=False)))


def print_unsupervised_dataset_example(example: Dict[str, List[int]], tokenizer: "PreTrainedTokenizer") -> None:
    print("input_ids:\n{}".format(example["input_ids"]))
    print("inputs:\n{}".format(tokenizer.decode(example["input_ids"], skip_special_tokens=False)))

def print_mt_dataset_example(example: Dict[str, List[int]], tokenizer: "PreTrainedTokenizer") -> None:
    print("input_ids:\n{}".format(example["input_ids"]))
    print("inputs:\n{}".format(tokenizer.decode(example["input_ids"], skip_special_tokens=False)))
    print("label_ids:\n{}".format(example["labels"]))
    print(
        "labels:\n{}".format(
            tokenizer.decode(list(filter(lambda x: x != IGNORE_INDEX, example["labels"])), skip_special_tokens=False)
        )
    )
    print("langs:\n{}".format(example['langs']))

def get_preprocess_and_print_func(
    tokenizer: "PreTrainedTokenizer",
    template: "Template",
    data_args: "DataArguments",
    training_args: "Seq2SeqTrainingArguments",
    stage: Literal["pt", "sft", "rm", "ppo"],
) -> Tuple[Callable, Callable]:
    if stage == "pt":
        preprocess_func = partial(preprocess_pretrain_dataset, tokenizer=tokenizer, data_args=data_args)
        print_function = partial(print_unsupervised_dataset_example, tokenizer=tokenizer)
    elif stage == "sft" and not training_args.predict_with_generate:
        if data_args.task == "mt":
            preprocess_func = partial(
                preprocess_mt_supervised_dataset, tokenizer=tokenizer, template=template, data_args=data_args
            )
            print_function = partial(print_mt_dataset_example, tokenizer=tokenizer)
        elif data_args.sft_packing:
            preprocess_func = partial(
                preprocess_packed_supervised_dataset, tokenizer=tokenizer, template=template, data_args=data_args
            )
        else:
            preprocess_func = partial(
                preprocess_supervised_dataset, tokenizer=tokenizer, template=template, data_args=data_args
            )

        print_function = partial(print_supervised_dataset_example, tokenizer=tokenizer)
    elif stage == "rm":
        preprocess_func = partial(
            preprocess_pairwise_dataset, tokenizer=tokenizer, template=template, data_args=data_args
        )
        print_function = partial(print_pairwise_dataset_example, tokenizer=tokenizer)
    else:
        preprocess_func = partial(
            preprocess_unsupervised_dataset, tokenizer=tokenizer, template=template, data_args=data_args
        )
        print_function = partial(print_unsupervised_dataset_example, tokenizer=tokenizer)

    return preprocess_func, print_function
